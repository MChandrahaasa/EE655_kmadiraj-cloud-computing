const Post = require('./model'); // Import the Post model


exports.createPost = async (req, res) => {
    try {
        const post = new Post(req.body);
        await post.save();
        res.status(201).json(post);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};


exports.getAllPosts = async (req, res) => {
    try {
        const posts = await Post.find();
        res.json(posts);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getPostsByUser = async (req, res) => {
    const userName = req.params.userName;
    try {
        const posts = await Post.find({ userName: userName });
        res.json(posts);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};
exports.getPostsByTitle = async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
        const posts = await Post.find({ title: { $regex: searchWord, $options: 'i' } });
        res.json(posts);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getPostsByContent = async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
        const posts = await Post.find({ content: { $regex: searchWord, $options: 'i' } });
        res.json(posts);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.deletePostsByUser = async (req, res) => {
    const userName = req.params.userName;
    try {
        await Post.deleteMany({ userName: userName });
        res.json({ message: 'All posts by user deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


exports.deletePostsByContent = async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
        await Post.deleteMany({ content: { $regex: searchWord, $options: 'i' } });
        res.json({ message: 'Posts containing the specified word in content deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


exports.countPostsByUser = async (req, res) => {
    const userName = req.params.userName;
    try {
        const count = await Post.countDocuments({ userName: userName });
        res.json({ userName: userName, postCount: count });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


