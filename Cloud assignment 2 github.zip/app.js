// Import required modules
const express = require('express');
const mongoose = require('mongoose');
const app = express();

const postRoutes = require('./routes');

mongoose.connect('mongodb://localhost:27017/blogDB', { 
  useNewUrlParser: true,
  useUnifiedTopology: true 
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('Could not connect to MongoDB', err));


app.use(express.json());

// postRoutes for requests to /posts
app.use('/posts', postRoutes);


app.get('/', (req, res) => {
  res.send('Blog API!');
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
