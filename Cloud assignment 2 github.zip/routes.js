const express = require('express');
const router = express.Router();
const postController = require('./controller'); 

router.post('/', postController.createPost);
router.get('/', postController.getAllPosts);
router.get('/user/:userName', postController.getPostsByUser);
router.get('/title/:searchWord', postController.getPostsByTitle);
router.get('/content/:searchWord', postController.getPostsByContent);
router.delete('/user/:userName', postController.deletePostsByUser);
router.delete('/content/:searchWord', postController.deletePostsByContent);
router.get('/count/:userName', postController.countPostsByUser);

module.exports = router;
