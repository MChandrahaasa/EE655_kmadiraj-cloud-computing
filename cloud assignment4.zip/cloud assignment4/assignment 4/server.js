require('dotenv').config({ path: 'key.env' }); // Load environment variables from key.env file
const express = require('express');
const bodyParser = require('body-parser'); // Import body-parser
const sql = require('mssql');
const port = process.env.PORT || 5001; // Use port from environment variable or default to 5001

const app = express();

const DbUserName = process.env.DbUserName;
const DbUserPassword = process.env.DbUserPassword;
const DbName = process.env.DbName;
const DbServerName = process.env.DbServerName;

const config = {
    user: DbUserName,
    password: DbUserPassword,
    server: DbServerName, 
    database: DbName,
    options: {
        encrypt: true, // For Azure SQL Database
        trustServerCertificate: false // Change this if you're working with self-signed certificates
    }
};

// Use body-parser middleware to parse form data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.post('/products', function(req, res) {
    const { Id, Name, Price, Quantity } = req.body;

    // Check if all required fields are present
    if (!Id || !Name || !Price || !Quantity) {
        return res.status(400).json({ error: 'Id, Name, Price, and Quantity are required' });
    }

    // Connect to the database
    sql.connect(config, function(err) {
        if (err) {
            console.error('Error connecting to database:', err);
            return res.status(500).send('Internal Server Error');
        }

        const request = new sql.Request();
        // Insert the new product into the database
        request.query(`INSERT INTO products (Id, name, price, quantity) VALUES (${Id}, '${Name}', ${Price}, ${Quantity})`, function(err, result) {
            if (err) {
                console.error('Error executing query:', err);
                return res.status(500).send('Internal Server Error');
            }
            
            // Respond with a success message
            res.status(201).json({ message: 'Product created successfully' });
        });
    });
});

// GET endpoint to retrieve a list of products
app.get('/products', function(req, res) {
    // Construct the SQL query based on the query parameters
    let query = 'SELECT * FROM products';
    const queryParams = req.query;

    // Check if query parameters are provided
    if (Object.keys(queryParams).length > 0) {
        query += ' WHERE';
        let conditions = [];

        // Iterate over the query parameters and construct conditions
        for (const [key, value] of Object.entries(queryParams)) {
            if (key === 'minPrice') {
                conditions.push(`Price >= ${parseFloat(value)}`);
            } else if (key === 'maxPrice') {
                conditions.push(`Price <= ${parseFloat(value)}`);
            } else if (key === 'minQuantity') {
                conditions.push(`Quantity >= ${parseInt(value)}`);
            } else if (key === 'maxQuantity') {
                conditions.push(`Quantity <= ${parseInt(value)}`);
            }
        }

        // Join the conditions using 'AND'
        query += ' ' + conditions.join(' AND ');
    }

    // Connect to the database
    sql.connect(config, function(err) {
        if (err) {
            console.error('Error connecting to database:', err);
            return res.status(500).send('Internal Server Error');
        }

        const request = new sql.Request();
        // Execute the SQL query
        request.query(query, function(err, result) {
            if (err) {
                console.error('Error executing query:', err);
                return res.status(500).send('Internal Server Error');
            }

            // Send the list of products as JSON response
            res.json(result.recordset);

            sql.close(); // Close the SQL connection after processing the request
        });
    });
});

// GET endpoint to retrieve a specific product by its ID
app.get('/products/:id', function(req, res) {
    // Parse the product ID from the request params
    const id = parseInt(req.params.id);

    // Connect to the database
    sql.connect(config, function(err) {
        if (err) {
            console.error('Error connecting to database:', err);
            return res.status(500).send('Internal Server Error');
        }

        const request = new sql.Request();
        // Set the parameterized query
        request.input('id', sql.Int, id);

        // Execute the SQL query to retrieve the product by its ID
        request.query('SELECT * FROM products WHERE Id = @id', function(err, result) {
            if (err) {
                console.error('Error executing query:', err);
                sql.close(); // Close the SQL connection
                return res.status(500).send('Internal Server Error');
            }

            // Check if the product with the given ID exists
            if (result.recordset.length === 0) {
                sql.close(); // Close the SQL connection
                return res.status(404).json({ error: 'Product not found' });
            }

            // Send the product details as JSON response
            res.json(result.recordset[0]);

            // Close the SQL connection after processing the request
            sql.close();
        });
    });
});

// PUT endpoint to update a product
app.put('/products/:id', function(req, res) {
    // Parse the product ID from the request params
    const id = parseInt(req.params.id);
    console.log('Product ID:', id);

    // Destructure the request body
    const { Name, Price, Quantity } = req.body;
    console.log('Request Body:', req.body);

    // Check if at least one of the attributes is provided for updating
    if (!Name && !Price && !Quantity) {
        return res.status(400).json({ error: 'At least one attribute (Name, Price, or Quantity) is required for updating' });
    }

    // Construct the SQL query to update the product
    let query = 'UPDATE products SET ';
    const updates = [];

    // Build the SET clause for the SQL query based on the provided attributes
    if (Name) {
        updates.push('Name = @Name');
    }
    if (Price) {
        updates.push('Price = @Price');
    }
    if (Quantity) {
        updates.push('Quantity = @Quantity');
    }

    // Join the updates into a single string
    query += updates.join(', ');

    // Add the WHERE clause to specify the product ID
    query += ' WHERE Id = @id';

    console.log('SQL Query:', query);

    // Connect to the database
    sql.connect(config, function(err) {
        if (err) {
            console.error('Error connecting to database:', err);
            return res.status(500).send('Internal Server Error');
        }

        const request = new sql.Request();
        // Set the parameterized query
        request.input('id', sql.Int, id);
        if (Name) {
            request.input('Name', sql.NVarChar, Name);
        }
        if (Price) {
            request.input('Price', sql.Decimal, Price);
        }
        if (Quantity) {
            request.input('Quantity', sql.Int, Quantity);
        }

        // Execute the SQL query with parameters
        request.query(query, function(err, result) {
            if (err) {
                console.error('Error executing query:', err);
                sql.close(); // Close the SQL connection
                return res.status(500).send('Internal Server Error');
            }

            console.log('Rows affected:', result.rowsAffected[0]);

            // Check if the product with the given product ID exists
            if (result.rowsAffected[0] === 0) {
                sql.close(); // Close the SQL connection
                return res.status(404).json({ error: 'Product not found' });
            }

            // Respond with a success message
            res.json({ message: 'Product updated successfully' });

            // Close the SQL connection after processing the request
            sql.close();
        });
    });
});


// DELETE endpoint to delete a product by ID
app.delete('/products/:id', function(req, res) {
    const id = parseInt(req.params.id); // Parse the product ID from the request parameters

    // Connect to the database
    sql.connect(config, function(err) {
        if (err) {
            console.error('Error connecting to database:', err);
            return res.status(500).send('Internal Server Error');
        }

        const request = new sql.Request();
        // Set the parameterized query
        request.input('id', sql.Int, id);

        // Execute the SQL query to delete the product by its ID
        request.query('DELETE FROM products WHERE Id = @id', function(err, result) {
            if (err) {
                console.error('Error executing query:', err);
                return res.status(500).send('Internal Server Error');
            }

            // Check if any rows were affected (i.e., if the product was deleted)
            if (result.rowsAffected[0] === 0) {
                return res.status(404).json({ error: 'Product not found' });
            }

            // Respond with a success message
            res.json({ message: 'Product deleted successfully' });

            // Close the SQL connection after processing the request
            sql.close();
        });
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Internal Server Error');
});

const server = app.listen(port, function () {
    console.log(`Server is running on port ${port}...`);
});
